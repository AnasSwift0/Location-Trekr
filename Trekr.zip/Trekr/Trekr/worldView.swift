//
//  worldView.swift
//  Trekr
//
//  Created by Anas Salah on 04/03/2023.
//

import MapKit
import SwiftUI


struct worldView: View {
    @EnvironmentObject var locations: Locations
    @State var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 26.820553, longitude: 30.802498),
        span: MKCoordinateSpan(latitudeDelta: 40, longitudeDelta: 40)
    )
    var body: some View {
        Map(coordinateRegion: $region, annotationItems: locations.places) {
            location in
            MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)) {
                NavigationLink(destination: ContentView(location: location)) {
                    Image(location.country)
                        .resizable()
                        .cornerRadius(10)
                        .frame(width: 80, height: 40)
                        .shadow(radius: 3)
                }

            }
        }
            .navigationTitle("Locations")
    }
}

struct worldView_Previews: PreviewProvider {
    static var previews: some View {
        worldView()
    }
}
