//
//  TrekrApp.swift
//  Trekr
//
//  Created by Anas Salah on 04/03/2023.
//

import SwiftUI

@main
struct TrekrApp: App {
    @StateObject var locations = Locations()
    
    var body: some Scene {
        WindowGroup {
            TabView {
                NavigationStack {
                    ContentView(location: locations.primary)
                }
                .tabItem {
                    Image(systemName: "airplane.circle.fill")
                    Text("Discover")
                }
                NavigationStack {
                    worldView()
                }
                .tabItem{
                    Image(systemName: "star")
                    Text("Locations")
                }
                NavigationStack {
                    TipView()
                }
                .tabItem {
                    Image(systemName: "list.bullet")
                    Text("Tips")
                }
            }
            .environmentObject(locations)  // <<<< to be in hole environment
            // and dont need to load it again and again
        }
    }
}
