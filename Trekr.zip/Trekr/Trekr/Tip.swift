//
//  Tip.swift
//  Trekr
//
//  Created by Anas Salah on 04/03/2023.
//

import Foundation

struct Tip: Decodable {
    
    
    let text: String
    let children: [Tip]?
    
    
}
