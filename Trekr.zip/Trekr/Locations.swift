//
//  Locations.swift
//  Trekr
//
//  Created by Anas Salah on 04/03/2023.
//

import Foundation

class Locations: ObservableObject {
    let places:  [Location]
    
    var primary: Location {
        places[4]
    }
    
    init() {
        let url = Bundle.main.url(forResource: "locations", withExtension: "json")!
        let data = try! Data(contentsOf: url)
        places = try! JSONDecoder().decode([Location].self, from: data)
    }
    
}
